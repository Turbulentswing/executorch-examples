import SwiftUI
import UniformTypeIdentifiers

@main
struct LungCADApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct ContentView: View {
    @State private var showImporter = false
    @State private var selectedFileNames: [String] = []

    var body: some View {
        NavigationStack {
            Form {
                Section("Research prototype") {
                    Text("LungCAD iPad")
                        .font(.title2.bold())
                    Text("This is a UI scaffold, not a working nodule detector.")
                        .foregroundStyle(.secondary)
                }
                Section("Input") {
                    Button("Choose DICOM files") { showImporter = true }
                    Text("Selected: \(selectedFileNames.count) file(s)")
                    ForEach(selectedFileNames.prefix(8), id: \.self) { name in
                        Text(name).font(.caption)
                    }
                }
                Section("Inference") {
                    Label("Not implemented", systemImage: "exclamationmark.triangle")
                    Text("Requires validated CT volume decoding, MONAI export, ExecuTorch/Core ML integration, and nodule postprocessing.")
                }
            }
            .navigationTitle("LungCAD")
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: [.data, .folder],
                          allowsMultipleSelection: true) { result in
                if case .success(let urls) = result {
                    selectedFileNames = urls.map(\.lastPathComponent)
                }
            }
        }
    }
}
