"""Inspect public MONAI lung-nodule model metadata; do not run clinical inference."""
import json
from pathlib import Path
from huggingface_hub import HfApi

REPO = 'MONAI/lung_nodule_ct_detection'
api = HfApi()
info = api.model_info(REPO, files_metadata=True)
files = []
for entry in info.siblings or []:
    files.append({'path': entry.rfilename, 'bytes': getattr(entry, 'size', None)})
result = {
    'repository': REPO,
    'revision': info.sha,
    'files': files,
    'notes': [
        'Listing files does not demonstrate model exportability.',
        'A native iPad app needs validated DICOM resampling, HU processing, 3D inference and NMS.',
        'No clinical performance is established by this inspection.'
    ]
}
Path('model-inspection.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
